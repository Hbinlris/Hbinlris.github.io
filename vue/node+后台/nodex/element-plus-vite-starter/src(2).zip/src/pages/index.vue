<template>
  <Logos my="4" />
  <HelloWorld msg="Hello Vue 3 + Element Plus + Vite" />
</template>
